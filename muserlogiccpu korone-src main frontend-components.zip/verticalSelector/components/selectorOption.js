import { createUseStyles } from "react-jss";
import Link from "../../link";
import { getTheme, themeType } from "../../../services/theme";

const useStyles = createUseStyles({
  wrapper: {
    width: '100%',
    color: 'var(--text-color-primary)',
    display: 'block',
    padding: '5px 10px',
    '&:hover': {
      background: p => p.theme === themeType.dark ? 'var(--white-color-hover)' : '#efefef',
    },
  },
  wrapperSelected: {
    borderLeft: '1px solid var(--text-color-secondary)',
    borderTop: '1px solid var(--text-color-secondary)',
    borderBottom: '1px solid var(--text-color-secondary)',

    backgroundColor: 'var(--white-color-hover)',
  },
  wrapperDisabled: {
    opacity: 0.25,
  },
  text: {
    fontSize: '16px',
  },
  textSelected: {
    fontWeight: '600',
  },
});

const SelectorOption = props => {
  const s = useStyles({theme: getTheme()});
  const el = <a onClick={props.onClick} className={s.wrapper + (props.selected ? ' ' + s.wrapperSelected : '') + (props.disabled ? ' ' + s.wrapperDisabled : '')}>
    <span className={s.text + (props.selected ? ' ' + s.textSelected : '')}>{props.name}</span>
  </a>

  if (props.url) {
    return <Link href={props.url}>
      {el}
    </Link>
  }

  return el;
}

export default SelectorOption;